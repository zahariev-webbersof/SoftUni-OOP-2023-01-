from project.sports_car import SportsCar

car = SportsCar()

print(car.move())
print(car.drive())
print(car.race())