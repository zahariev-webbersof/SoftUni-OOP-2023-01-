from project.dog import Dog

a = Dog()
print(a.bark())
print(a.eat())